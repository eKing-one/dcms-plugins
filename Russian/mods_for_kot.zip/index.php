<?php

require 'sid.php'; // сессии
require 'config.php'; // конфиг. файл
$link = connect_db(); // соединение с бд

// проверка авторизации
if (!empty($_SESSION['us'])) {
	$link = connect_db();
   	list($user, $id, $ps) = check_login($link);
   	whorm(0, 'index');
}

// успешная авторизация
if (isset($_GET['good'])) msg('Авторизация прошла успешно!');
// провал авторизации
if (isset($_GET['noavt'])) err('Авторизация провалена!');
// выход с ника
if (isset($_GET['exit'])) msg('Мы ждем вас снова!');

include 'head.php'; // шапка

$ref = mt_rand(10000, 1000000);

// Запись гостей
  if ($ipl && $agent && empty($_SESSION['us']))
  {
  	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `guests` WHERE `ip` = '$ipl' AND `ua` = '".check($agent)."' LIMIT 1"), 0) == 1)
    {
     	$guests = mysql_fetch_assoc(mysql_query("SELECT * FROM `guests` WHERE `ip` = '$ipl' AND `ua` = '".check($agent)."' LIMIT 1"));

     	mysql_query("UPDATE `guests` SET `date_last` = ".time().", `url` = '$site', `pereh` = '".($guests['pereh'] + 1)."' WHERE `ip` = '$ipl' AND `ua` = '".mysql_real_escape_string(check($agent))."' LIMIT 1");
    }
    else
    {
     	mysql_query("INSERT INTO `guests` (`ip`, `ua`, `date_aut`, `date_last`, `url`) VALUES ('$ipl', '".check($agent)."', '".time()."', '".time()."', '$site')");
    }
}

// Кол-во гостей
$col_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `guests` WHERE `date_last` > '" . (time() - 100) . "' AND `pereh` > '0'"), 0);
// Кол-во авторизированных
$kol = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `onl` + '200' > '" . time() . "'"), 0);

// заголовок
echo $div_title . 'В онлайне: <a href="online.php?'.$ref.'">
		   <span style="color: #003A77;">(' . $kol . ')</span></a>
		   <span style="color: #003A77;">+ ' . $col_g . '</span> гостей
		   ' . $div_end;

########################
// посылаем на хуй при нехороших запросах
if (isset($_GET['isset']) && $_GET['isset'] == 403)
{
   err('Доступ запрещен!');
} elseif (isset($_GET['isset']) && $_GET['isset'] == 404)
{
   err('Страница не найдена!');
}
########################

echo $div_left; // ********************
// Админка
echo (!empty($_SESSION['us']) && $user['level'] == 4 || $user['level'] == 5)
     ?
	 $div_tworazdel . '<img src="ico/panel.gif" alt=""/> <a href="admin.php?'.$ref.'">Админ-панель</a></b>' . $div_end
	 :
	 '';
// Модерка
echo (!empty($_SESSION['us']) && $user['level'] >= 1 && $user['level'] <= 3)
     ?
	 $div_tworazdel . '<img src="ico/panel.gif" alt=""/> <a href="moder.php?'.$ref.'">Модер-панель</a></b>' . $div_end
	 :
	 '';

// счетчик чата
$_numChat = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `room` LIKE 'room%' AND `onl` + '200' > '" . time() . "'"), 0);
// счетчик форума
$_numFor = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `room` = 'forum' AND `onl` + '200' > '" . time() . "'"), 0);
// счетчик групп
$numGr = mysql_result(mysql_query("SELECT COUNT(*) FROM `groups` WHERE `in_group` = ''"), 0);
// счетчик заметок
$notes = mysql_result(mysql_query("SELECT COUNT(*) FROM `zametki` WHERE `look` = '1'"), 0);
// счетчик разделов тотализатора
$total_r = mysql_result(mysql_query("SELECT COUNT(*) FROM `sport_razdel`"), 0);
// счетчик матчей тотализатора
$total_m = mysql_result(mysql_query("SELECT COUNT(*) FROM `sport_match`"), 0);
// счетчик обменника
$zc = mysql_result(mysql_query("SELECT COUNT(*) FROM `fo_files` WHERE `moder` = '0'"), 0);
// счетчик разделов газеты
$gazeta_r = mysql_result(mysql_query("SELECT COUNT(*) FROM `gazeta_razdel`"), 0);
// счетчик стетей газеты
$gazeta_a = mysql_result(mysql_query("SELECT COUNT(*) FROM `gazeta_article`"), 0);

if (!empty($_SESSION['us'])) {
	if (rat($user['id']) < 30) $red = '<span style="color: #FF0000;">ред</span>';
	else $red = 'ред';
}

echo (empty($_SESSION['us']))
      ?
	  '<div class="razdel" style="padding:4px;font-size: 13px;text-align:right;">
	  <a href="aut.php?'.$ref.'">Вход</a> | <a href="reg.php?'.$ref.'">Регистрация</a></div>'
	  :
	  '<div class="razdel" style="padding:2px;font-size: 13px;text-align:left;">
	  <img src="ico/icon_stranica.gif" alt=""/> <a href="/'.$user['id'].'">Моя страница</a>
	  <a href="edit.php?do=rating">(' . rat($user['id']) . '%)</a>
	  [<a href="edit.php?'.$ref.'">' . $red . '</a> |
	  <a href="settings.php?'.$ref.'">настр</a>]
	  </div>';

$_news = mysql_fetch_assoc(mysql_query("SELECT `date` FROM `news` ORDER BY `id` DESC LIMIT 1"));
$_new_news = mysql_result(mysql_query("SELECT COUNT(*) FROM `news` WHERE `date` > '" . (time() - 86400) . "'"), 0);

$new_news = (!empty($_new_news)) ? ' <span style="color: #FF0000;">+' . $_new_news . '</span>' : '';

$_date = ($_news != '') ? '(' . date('d.m', $_news['date']) . ')' . $new_news : '';

echo (empty($_SESSION['us'])) 
      ?
	  $div_tworazdel . '<img src="ico/info.gif" alt=""/> <a href="faq.php?do=what">Что такое ' . $site . '?</a>' . $div_end
	  :
	  $div_tworazdel . '<img src="ico/novosti.gif" alt=""/> <a href="news.php?'.$ref.'">Новости</a> ' . $_date . $div_end;

echo $div_aut . '
      <img src="ico/meets.gif" alt=""/> <a href="love/index.php?do=users">Знакомства</a> | 
      <a href="love/index.php?'.$ref.'">Поиск</a>
	  ' . $div_end . $div_tworazdel . '
	  <img src="ico/lider.gif" alt=""/> <a href="liders.php?'.$ref.'">Лидеры</a>
	  ' . $div_end . $div_razdel . '
	  <img src="ico/zone.gif" alt=""/> <a href="fo/index.php?'.$ref.'">Зона обмена</a> (' . $zc . ') |
	  <a href="fo/search.php?'.$ref.'">Поиск файлов</a>
	  ' . $div_end . $div_razdel . '
      <img src="ico/servisy.gif" alt=""/> <a href="service/index.php?'.$ref.'">Сервисы</a><br/>
	  <img src="ico/muz.gif" alt=""/> <a href="music/index.php?'.$ref.'">Вся музыка мира + Поиск!</a><br/>
	  <img src="ico/mob.gif" alt=""/> <a href="films/index.php?'.$ref.'">Мобильные фильмы!</a>
	  ' . $div_end . $div_tworazdel . '
	  <img src="ico/zametki.gif" alt=""/> <a href="zametki.php?'.$ref.'">Люди пишут</a> (' . $notes . ')<br/>
	  <img src="ico/groups.gif" alt=""/> <a href="groups/index.php?'.$ref.'">Группы</a> (' . $numGr . ')
	  ' . $div_end . $div_razdel . '
	  <img src="ico/chat.gif" alt=""/> <a href="chat/index.php?'.$ref.'">Чат</a> (' . $_numChat . ')<br/>
	  <img src="ico/forum.gif" alt=""/> <a href="forum/index.php?'.$ref.'">Форум</a> (' . $_numFor . ')
	  ' . $div_end . $div_tworazdel . '
	  <img src="ico/novosti.gif" alt=""/> <a href="gazeta.php?'.$ref.'">Газета</a> (' . $gazeta_r . '/' . $gazeta_a . ')<br/>
	  <img src="ico/fm.gif" alt=""/> <a href="total.php?'.$ref.'">Тотализатор</a> (' . $total_r . '/' . $total_m . ')<br/>
	  <img src="ico/info.gif" alt=""/> <a href="faq.php?'.$ref.'">Информация + Помощь</a><br/>
	  <img src="ico/games.gif" alt=""/> <a href="games/index.php?'.$ref.'">Онлайн-игры</a><br/>' . $div_end;

echo (!empty($_SESSION['us']))
      ?
	  $div_razdel . '<img src="ico/logout.gif" alt=""/> <a href="exit.php?'.$ref.'"><span style="color: #FF0000;">Выход</span></a>' . $div_end
	  :
	  '';

echo $div_end; // ********************
/*Узнаю, кто продаёт, анально накажу (c) FCDD :-D*/
/*Вывод форума*/
////-------///
	$inForum = mysql_query("SELECT f_them .*, (SELECT COUNT(id) FROM f_message WHERE f_message.tid = f_them.id) AS s
	FROM f_them  ORDER BY last DESC, id DESC LIMIT 3");

	if (mysql_num_rows($inForum) != false) { 		while($inF = mysql_fetch_assoc($inForum))		{ 
  											if ($inF['s'] > 10) {	$pg = ceil($inF['s'] / 10);	$st = '&amp;page=' . $pg;	} else {
 		 				$st = '';	}
echo "<p align = 'left'>";
			echo $div_action . '<a href="forum/?do=them&amp;r='.$inF['razdel_id'].'&amp;p='.$inF['rid'].'&amp;t='.$inF['id'].$st.'">' . $inF['name'] . ' (' . $inF['s'] . ')</a>' . $div_end;
echo "</p>";
}
}
////Конец///
include 'foot.php';

?>