<?php
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';

$set['title']='Банк фермеров'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();
err();
aut();
if (isset($user)){
$action=htmlspecialchars(trim($_GET['action']));

switch ($action){

default:
echo 'Здравствуйте, '.$user['nick'].'! ';
echo 'На ваших счетах имеется:<br/>';
echo 'Монеты: '.$user['balls'].'<br/>';
echo 'Деньги: '.$user['farm_gold'].'<br/>';
echo 'Курс обмена 1 к 100<br/>';
echo '<form action="bank.php?action=change" method="post">';
echo 'Сколько монет хотите обменять:<br/>';
echo '<input name="num" type="text" value=""/><br/>';
echo '<input type="submit" value="Обменять"/>';
echo '</form>';
echo '&raquo; <a href="change.php">Перевод денег</a><br/>';
break;

case 'change':
$num=(int)$_POST['num'];
if(!$num || $num<1){echo 'Пустые параметры!';break;};
if($user['balls']<$num){echo 'У вас нет столько монет! <br>&raquo;<a href="bank.php"> Вернуться в банк</a><br/>';break;};
$baks=$num*100;
mysql_query("UPDATE `user` SET `farm_gold`=`farm_gold`+'$baks',`balls`=`balls`-'$num' WHERE `id`='".$user['id']."'");
echo 'Обмен успешно завершен!';
echo '<br/>&raquo; <a href="bank.php">Вернуться в банк</a><br/>';
break;
};
echo "<div class='foot'>";
echo "&raquo; <a href='my.php'>Моя ферма</a><br/>";
echo "&laquo; <a href='index.php'>Назад</a><br/>";
echo "</div>";
}else{
echo '<div class="msg">Ферма доступна только для авторизованных пользователей!</div>';};
include_once '../sys/inc/tfoot.php';
?>