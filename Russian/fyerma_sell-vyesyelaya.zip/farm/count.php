<?
/*
Автор скрипта: MoD
ICQ: 3536335
Скрипт нельзя 
кидать в паблик, 
барыжить(продавать) им, 
давать друзьям!
*/
echo mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `date_last` > '".(time()-600)."' AND `url` like '/fermer/%'"), 0).' человек';
echo '<br />';?>