<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();
$set['title']='Веселая ферма :: Приветствие';
include_once '../sys/inc/thead.php';
title();
aut();

$dog = mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_dog` WHERE  `id_user` = '".$user['id']."'  LIMIT 1"),0);
if ($dog==0)
{
mysql_query("INSERT INTO `farm_dog` (`id_user`,`time`) VALUES  ('".$user['id']."','0') ");
}

$post = mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE  `id_user` = '".$user['id']."'  LIMIT 1"), 0);
if ($post<5)
{
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
}

$chk=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_user` WHERE `uid` = '".$user['id']."'"), 0);

if ($chk!=0)
{
header("Location: /farm/garden/");
exit();
}

mysql_query("INSERT INTO `farm_user` SET `uid` = '".$user['id']."'");

include_once 'inc/str.php';
farm_event();

echo "<div class='rowup'>";
echo "<center><img src='/farm/img/logo.png' alt='Ферма' /></center><br />&raquo; Вас приветствует игра Мобильная ферма!<br />&raquo; Чтобы начать играть, зайдите в магазин семян, купите пять семян Гороха, перейдите к своим грядкам и рассадите все семена по грядкам. Затем полейте грядки и ждите созревания урожая. Поливать грядки можно один раз в полчаса, полив ускорит созревание растения на полчаса. Помните! Каждое действие на Ваших грядках отнимает несколько единиц здоровья. Сейчас у Вас их сто. Здоровье и другая информация, а также погода расположена в верхнем блоке каждой страницы. Став более богатым и опытным фермером, Вы можете покупать новые грядки, покупать Комбайны, изучать Умения и многое другое. Желаем удачи в игре!<br />С уважением, разработчик сайта</div>";
echo "<div class='rowdown'>";
echo "<img src='img/garden.png' alt='' class='rpg' /> <a href='/farm/garden/'>Мои грядки</a></div>";

include_once '../sys/inc/tfoot.php';
?>