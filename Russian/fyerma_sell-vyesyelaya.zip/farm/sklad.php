<?php
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();
if (isset($_GET['id']))
{
$int=intval($_GET['id']);
}
$set['title']='Весёлая ферма : Склад';
include_once '../sys/inc/thead.php';
title();
err();

$fuser=mysql_fetch_array(mysql_query("SELECT * FROM `farm_user` WHERE `uid` = '".$user['id']."' LIMIT 1"));

if (isset($_GET['sell_all']))
{
mysql_query("DELETE FROM `farm_semen` WHERE `id_user`= '".$user['id']."'");
$sumd = intval($_SESSION['sum']);
mysql_query("UPDATE `farm_user` SET `gold` = '".($fuser['gold']+$sumd)."' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Все семена проданы за '.intval($_SESSION['sum']).' золота');
unset($_SESSION['sum']);

header("Location: /farm/sklad");
exit;
}

if(isset($_GET['sell_ok']))
{
$semen=mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '".intval($_SESSION['plid'])."'  LIMIT 1"));

add_farm_event('Семена растения '.$semen['name'].' продан. Получено '.intval($_SESSION['dohod']).' золота.');

}

aut();

include 'inc/str.php';

if(isset($_GET['id'])){
$post=mysql_fetch_array(mysql_query("select * from `farm_semen` WHERE `id`= '".intval($_GET['id'])."' LIMIT 1")); 
$semen=mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '".$post['semen']."'  LIMIT 1")); 

unset($_SESSION['plid']);

$_SESSION['plid'] = $post['semen'];

$dohod=$post['kol']*$semen['cena'];


unset($_SESSION['dohod']);
$_SESSION['dohod'] = $dohod;
if(isset($_GET['sell']))
{
$dohod = intval($_SESSION['dohod']);
mysql_query("UPDATE `farm_user` SET `gold` = '".($fuser['gold']+$dohod)."' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("DELETE FROM `farm_semen` WHERE `id` = ".intval($_GET['id'])." ");
header('Location: /farm/sklad?sell_ok');
}

farm_event();

echo "<div class='rowup'><center>";
echo "<img src='/farm/bush/".$post['semen'].".png' alt=''></center><br/> <b>Семена ".$semen['name']."</b><br/>";
echo "&raquo; Количество: <b>".$post['kol']."</b> <br/>";
echo "&raquo; Цена за единицу: <b>".$post['cena']."</b> <br/>";

echo "&raquo; Общий доход: <b>".$dohod."</b> </div>";

echo "<form method='post' action='?id=".$int."&amp;sell'>\n";
echo "<input type='submit' name='save' value='Продать' />\n";
echo "</form>\n";
echo "<div class='rowup'>";
echo "<img src='/img/back.png' alt='' class='rpg' /> <a href='/farm/sklad'>Склад</a><br/>";
echo "</div>";

}
else
{

farm_event();

$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_semen` WHERE `id_user` = '".$user['id']."'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];


if ($k_post==0)
{
echo "<div class='err'>На складе семян нет</div>";
}

if ($k_post!=0)
{
$rssum=mysql_query("SELECT * FROM `farm_semen` WHERE `id_user` = '".$user['id']."'");
$_SESSION['sum']=0;

while ($item=mysql_fetch_array($rssum))
{
$plsum = mysql_fetch_array(mysql_query("SELECT * FROM `farm_plant` WHERE `id` = '".$item['semen']."' LIMIT 1"));
$plussum = $plsum['cena']*$item['kol'];
$_SESSION['sum'] = $plussum+$_SESSION['sum'];
}

echo "<div class='rowdown'>";
echo "<img src='/img/add.png' alt='' class='rpg' /> <a href='/farm/sklad?sell_all'>Продать всё за ".intval($_SESSION['sum'])." золота</a></div>";
}


$res = mysql_query("select * from `farm_semen` WHERE `id_user` = '".$user['id']."' LIMIT $start, $set[p_str];");

while ($post = mysql_fetch_array($res)){
if ($num==1)
{
echo "<div class='rowdown'>";
$num=0;
}
else
{
echo "<div class='rowup'>";
$num=1;
}

$semen=mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '".$post['semen']."'  LIMIT 1")); 

echo "<img src='/farm/bush/".$post['semen'].".png' height='20' width='20'><b></b> <a href='?id=$post[id]'>".$semen['name']."</a> [".$post['kol']."] ";
echo "(<a href='?id=".$post['id']."&amp;sell'><span class='off'>Продать</span></a>)</div>";
}


if ($k_page>1)str('?',$k_page,$page); // Вывод страниц
}
echo "<div class='rowdown'>";
echo "<img src='/farm/img/garden.png' /> <a href='/farm/garden/'>Назад</a><br/>";
echo "</div>";

include_once '../sys/inc/tfoot.php';

?>