<?
include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/user.php';
only_reg();

if (isset($_GET['start']))
{

$fuser=mysql_fetch_array(mysql_query("SELECT * FROM `farm_user` WHERE `uid` = '".$user['id']."' LIMIT 1"));

if ($fuser['k_poliv']!=0)
{
$irnum=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `time` > '".time()."' AND `time_water` < '".time()."'"), 0);
if ($irnum!=0)
{
if ($fuser['k_poliv']==1)
{
$irtime=10*$irnum;
$irexp=50*$irnum;
}
if ($fuser['k_poliv']==2)
{
$irtime=5*$irnum;
$irexp=100*$irnum;
}
if ($fuser['k_poliv']==3)
{
$irtime=3*$irnum;
$irexp=150*$irnum;
}
$nwtime=time()+$irtime;

mysql_query("UPDATE `farm_user` SET `poliv` = `poliv`+'$irnum' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `exp` = `exp`+'$irexp' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_poliv_time` = '$nwtime' WHERE `uid` = '".$user['id']."' LIMIT 1");

$query=mysql_query("SELECT * FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `time` > '".time()."' AND `time_water` < '".time()."'");
while ($gr=mysql_fetch_array($query))
{
mysql_query("UPDATE `farm_gr` SET `time` = `time`-'1800' WHERE `id` = '".$gr['id']."' LIMIT 1");
$tmna=time()+1800;
mysql_query("UPDATE `farm_gr` SET `time_water`='".$tmna."' WHERE `id` = '".$gr['id']."' LIMIT 1");
}

add_farm_event('Успешно полито '.$irnum.' грядок. Потрачено '.$irtime.' секунд, получено '.$irexp.' опыта');

}
else
{
add_farm_event('Нет грядок, нуждающихся в поливе');
}

}
else
{
add_farm_event('У Вас нет Оросителя');
}
}
header("Location: /farm/garden/");
exit();
?>