<?
include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/user.php';
only_reg();
$set['title']='Сеялка :: Выбор семян';
include_once '../../sys/inc/thead.php';
title();
err();

include_once '../inc/str.php';
farm_event();

if (isset($_GET['select']))
{
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_semen` WHERE `id_user` = '".$user['id']."'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];

if ($k_post==0)
{
add_farm_event('У Вас нет семян на складе. Вы перенаправлены в магазин семян');
header("Location: /farm/shop/");
exit();
}

$res = mysql_query("select * from `farm_semen` WHERE `id_user` = '".$user['id']."' LIMIT $start, $set[p_str];");

while ($post = mysql_fetch_array($res)){
if ($num==1)
{
echo "<div class='rowdown'>";
$num=0;
}
else
{
echo "<div class='rowup'>";
$num=1;
}

$semen=mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '".$post['semen']."'  LIMIT 1")); 
echo "<img src='/farm/plants/".$post['semen'].".png' height='12' width='12'> <a href='/farm/combine/seeder.php?id=".$post['id']."&start'>".$semen['name']."</a> (".$post['kol']." шт.)";
echo "</div>";
}
if ($k_page>1)str('?',$k_page,$page);

echo "<div class='rowdown'>";
echo "<img src='/farm/img/garden.png' alt='' class='rpg' /> <a href='/farm/garden/'>Отмена</a>";
echo "</div>";
include_once H.'sys/inc/tfoot.php';
exit();
}


if (isset($_GET['start']) && isset($_GET['id']) && is_numeric($_GET['id']))
{

$id=abs(intval($_GET['id']));

$chk=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_semen` WHERE `id` = '".$id."' AND `id_user` = '".$user['id']."'"), 0);

if ($chk==0)
{
add_farm_event('Данные семена не Ваши, либо они не существуют');
header("Location: /farm/garden/");
exit();
}

$fuser=mysql_fetch_array(mysql_query("SELECT * FROM `farm_user` WHERE `uid` = '".$user['id']."' LIMIT 1"));

$post=mysql_fetch_array(mysql_query("SELECT * FROM `farm_semen` WHERE `id` = '".$id."' LIMIT 1"));
$plant=mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '".$post['semen']."'  LIMIT 1"));
$irnum=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `semen` = '0'"), 0);

if ($post['kol']<$irnum)
{
add_farm_event('Не хватает семян');
header("Location: /farm/garden/");
exit();
}

if ($fuser['k_posadka']!=0)
{
$irnum=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `semen` = '0'"), 0);
if ($irnum!=0)
{
if ($fuser['k_posadka']==1)
{
$irtime=10*$irnum;
$irexp=50*$irnum;
}
if ($fuser['k_posadka']==2)
{
$irtime=5*$irnum;
$irexp=100*$irnum;
}
if ($fuser['k_posadka']==3)
{
$irtime=3*$irnum;
$irexp=150*$irnum;
}
$nwtime=time()+$irtime;

mysql_query("UPDATE `farm_user` SET `posadka` = `posadka`+'$irnum' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `exp` = `exp`+'$irexp' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_posadka_time` = '".$nwtime."' WHERE `uid` = '".$user['id']."' LIMIT 1");

$query=mysql_query("SELECT * FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `semen` = '0'");
while ($gr=mysql_fetch_array($query))
{
$tmna=time()+$plant['time'];
mysql_query("UPDATE `farm_gr` SET `time` = '".$tmna."' WHERE `id` = '".$gr['id']."' LIMIT 1");
mysql_query("UPDATE `farm_gr` SET `semen` = '".$post['semen']."' WHERE `id` = '".$gr['id']."' LIMIT 1");
mysql_query("UPDATE `farm_gr` SET `udobr` = '0' WHERE `id` = '".$gr['id']."' LIMIT 1");
if ($post['kol']>=2)
{
mysql_query("UPDATE `farm_semen` SET `kol` = `kol`-'1' WHERE `id` = ".$id." LIMIT 1");
}
else
{
mysql_query("DELETE FROM `farm_semen` WHERE `id` = ".$id."");
}
}

add_farm_event('Успешно посажено '.$irnum.' растений '.$plant['name'].'. Потрачено '.$irtime.' секунд, получено '.$irexp.' опыта');

}
else
{
add_farm_event('Нет свободных грядок');
}

}
else
{
add_farm_event('У Вас нет Сеялки');
}
}
if (!isset($_GET['select']))
{
header("Location: /farm/garden/");
exit();
}
?>