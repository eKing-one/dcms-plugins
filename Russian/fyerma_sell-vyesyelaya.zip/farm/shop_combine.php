<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();
$set['title']='Весёлая ферма :: Магазин техники';
include_once '../sys/inc/thead.php';
title();
aut();

$fuser=mysql_fetch_array(mysql_query("SELECT * FROM `farm_user` WHERE `uid` = '".$user['id']."' LIMIT 1"));

if (isset($_GET['seeder_up']))
{
if ($fuser['k_posadka']==0 && $fuser['gems']>=100)
{
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'100' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_posadka` = '1' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно приобрели [b]Сеялку[/b] первого уровня. Потрачено 100 алмазов');
}
if ($fuser['k_posadka']==0 && $fuser['gems']<100)
{
$cntt=100-$fuser['gems'];
add_farm_event('У Вас не хватает '.$cntt.' алмазов для покупки [b]Сеялки[/b] первого уровня');
}

if ($fuser['k_posadka']==1 && $fuser['gems']>=30)
{
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'30' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_posadka` = '2' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно улучшили [b]Сеялку[/b] до второго уровня. Потрачено 30 алмазов');
}
if ($fuser['k_posadka']==1 && $fuser['gems']<30)
{
$cntt=30-$fuser['gems'];
add_farm_event('У Вас не хватает '.$cntt.' алмазов для улучшения [b]Сеялки[/b] до второго уровня');
}

if ($fuser['k_posadka']==2 && $fuser['gems']>=50)
{
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'50' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_posadka` = '3' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно улучшили [b]Сеялку[/b] до третьего уровня. Потрачено 50 алмазов');
}
if ($fuser['k_posadka']==2 && $fuser['gems']<50)
{
$cntt=50-$fuser['gems'];
add_farm_event('У Вас не хватает '.$cntt.' алмазов для улучшения [b]Сеялки[/b] до третьего уровня');
}
header("Location: /farm/shop_combine.php?seeder");
exit();
}


if (isset($_GET['irrigation_up']))
{
if ($fuser['k_poliv']==0 && $fuser['gems']>=100)
{
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'100' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_poliv` = '1' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно приобрели [b]Ороситель[/b] первого уровня. Потрачено 100 алмазов');
}
if ($fuser['k_poliv']==0 && $fuser['gems']<100)
{
$cntt=100-$fuser['gems'];
add_farm_event('У Вас не хватает '.$cntt.' алмазов для покупки [b]Оросителя[/b] первого уровня');
}

if ($fuser['k_poliv']==1 && $fuser['gems']>=30)
{
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'30' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_poliv` = '2' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно улучшили [b]Ороситель[/b] до второго уровня. Потрачено 30 алмазов');
}
if ($fuser['k_poliv']==1 && $fuser['gems']<30)
{
$cntt=30-$fuser['gems'];
add_farm_event('У Вас не хватает '.$cntt.' алмазов для улучшения [b]Оросителя[/b] до второго уровня');
}

if ($fuser['k_poliv']==2 && $fuser['gems']>=50)
{
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'50' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `k_poliv` = '3' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно улучшили [b]Ороситель[/b] до третьего уровня. Потрачено 50 алмазов');
}
if ($fuser['k_poliv']==2 && $fuser['gems']<50)
{
$cntt=50-$fuser['gems'];
add_farm_event('У Вас не хватает '.$cntt.' алмазов для улучшения [b]Оросителя[/b] до третьего уровня');
}
header("Location: /farm/shop_combine.php?irrigation");
exit();
}



include_once H.'/farm/inc/str.php';
farm_event();


if (isset($_GET['seeder']))
{
echo "<div class='rowup'>";
echo "<table class='post'><tr><td><img src='/farm/img/seeder_big.png' alt='' /></td><td>";
echo "Машина для автоматизированного посева семян гнездовым методом. Облегчает труд фермера - одним кликом засевает все грядки</td></tr></table>";
echo "Использовать только при посеве одного вида семян на все грядки.<br />";

if ($fuser['k_posadka']==1)
{
echo "На данном уровне сажает семена на все участки земли за раз, расходует по 10 секунд на одну грядку и дает дополнительно <img src='/farm/img/exp.png' alt='' class='rpg' />50 к опыту при использовании на нём<br />";
}
if ($fuser['k_posadka']==2)
{
echo "На данном уровне сажает семена на все участки земли за раз, расходует по 5 секунд на одну грядку и дает дополнительно <img src='/farm/img/exp.png' alt='' class='rpg' />100 к опыту при использовании на нём<br />";
}
if ($fuser['k_posadka']==3)
{
echo "На данном уровне сажает семена на все участки земли за раз, расходует по 3 секунды на одну грядку и дает дополнительно <img src='/farm/img/exp.png' alt='' class='rpg' />150 к опыту при использовании на нём<br />";
}


if ($fuser['k_posadka']==0)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'><a href='?seeder_up'>Купить сеялку первого уровня за <img src='/farm/img/gems.png' alt='' class='rpg' />100</a></span><br />";
echo "Будет садить семена на все грядки за раз, расходовать 10 секунд на каждый участок и давать <img src='/farm/img/exp.png' alt='' class='rpg' />50 к опыту";
}

if ($fuser['k_posadka']==1)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'><a href='?seeder_up'>Улучшить сеялку до второго уровня за <img src='/farm/img/gems.png' alt='' class='rpg' />30</a></span><br />";
echo "Будет садить семена на все грядки за раз, расходовать 5 секунд на каждый участок и давать <img src='/farm/img/exp.png' alt='' class='rpg' />100 к опыту";
}

if ($fuser['k_posadka']==2)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'><a href='?seeder_up'>Улучшить сеялку до третьего уровня за <img src='/farm/img/gems.png' alt='' class='rpg' />50</a></span><br />";
echo "Будет садить семена на все грядки за раз, расходовать 3 секунды на каждый участок и давать <img src='/farm/img/exp.png' alt='' class='rpg' />150 к опыту";
}

if ($fuser['k_posadka']==3)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'>Сеялка третьего уровня</span> (максимальный уровень)<br />";
echo "На данном уровне садит семена на все грядки за раз, расходует по 3 секунды на каждый участок и даёт <img src='/farm/img/exp.png' alt='' class='rpg' />150 к опыту";
}
echo '</div>';
}

if (isset($_GET['irrigation']))
{

echo "<div class='rowup'>";
echo "<table class='post'><tr><td><img src='/farm/img/irrigation_big.png' alt='' /></td><td>";
echo "Система орошения для механизации полива растений на огороде. Облегчает труд фермера - одним кликом польёт все грядки</td></tr></table>";
echo "Активизируется перед каждым поливом<br />";

if ($fuser['k_poliv']==1)
{
echo "На данном уровне поливает все участки земли за раз, расходует по 10 секунд на одну грядку и дает дополнительно <img src='/farm/img/exp.png' alt='' class='rpg' />50 к опыту при использовании на нём<br />";
}
if ($fuser['k_poliv']==2)
{
echo "На данном уровне поливает все участки земли за раз, расходует по 5 секунд на одну грядку и дает дополнительно <img src='/farm/img/exp.png' alt='' class='rpg' />100 к опыту при использовании на нём<br />";
}
if ($fuser['k_poliv']==3)
{
echo "На данном уровне поливает все участки земли за раз, расходует по 3 секунды на одну грядку и дает дополнительно <img src='/farm/img/exp.png' alt='' class='rpg' />150 к опыту при использовании на нём<br />";
}


if ($fuser['k_poliv']==0)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'><a href='?irrigation_up'>Купить ороситель первого уровня за <img src='/farm/img/gems.png' alt='' class='rpg' />100</a></span><br />";
echo "Будет поливать все грядки за раз, расходовать 10 секунд на каждый участок и давать <img src='/farm/img/exp.png' alt='' class='rpg' />50 к опыту";
}

if ($fuser['k_poliv']==1)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'><a href='?irrigation_up'>Улучшить ороситель до второго уровня за <img src='/farm/img/gems.png' alt='' class='rpg' />30</a></span><br />";
echo "Будет поливать все грядки за раз, расходовать 5 секунд на каждый участок и давать <img src='/farm/img/exp.png' alt='' class='rpg' />100 к опыту";
}

if ($fuser['k_poliv']==2)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'><a href='?irrigation_up'>Улучшить ороситель до третьего уровня за <img src='/farm/img/gems.png' alt='' class='rpg' />50</a></span><br />";
echo "Будет поливать все грядки за раз, расходовать 3 секунды на каждый участок и давать <img src='/farm/img/exp.png' alt='' class='rpg' />150 к опыту";
}

if ($fuser['k_poliv']==3)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <span class='underline'>Ороситель третьего уровня</span> (максимальный уровень)<br />";
echo "На данном уровне поливает все грядки за раз, расходует по 3 секунды на каждый участок и даёт <img src='/farm/img/exp.png' alt='' class='rpg' />150 к опыту";
}

echo "</div>";
}

if (!isset($_GET['irrigation']))
{
echo "<div class='rowdown'><img src='/farm/img/irrigation_small.png' alt='' class='rpg' /> <a href='?irrigation'>Ороситель</a>";
if ($fuser['k_poliv']!=0)
{
echo " (".$fuser['k_poliv'].")";
}
echo "</div>";
}
if (!isset($_GET['seeder']))
{
echo "<div class='rowdown'>";
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <a href='?seeder'>Сеялка</a>";
if ($fuser['k_posadka']!=0)
{
echo " (".$fuser['k_posadka'].")";
}
echo "</div>";
}
echo "<div class='rowdown'>";
echo "<img src='/farm/img/garden.png' alt='' class='rpg' /> <a href='/farm/garden/'>Мои грядки</a>";
echo "</div>";
include_once '../sys/inc/tfoot.php';
?>