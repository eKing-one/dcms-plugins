<?php
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();
$set['title']='Весёлая ферма :: Магазин семян';
include_once '../sys/inc/thead.php';
title();
err();

$idpl=intval($_SESSION['plidb']);
$plant = mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '$idpl'  LIMIT 1"));

if (isset($_GET['buy_ok']))
{
add_farm_event('Семена растения '.$plant['name'].' успешно приобретены');
}

if (isset($_GET['buy_no']))
{
add_farm_event('Не хватает денег');
}

aut();
include 'inc/str.php';
farm_event();

if(isset($_GET['id'])){
include 'inc/shop_info.php';
}else{
include 'inc/shop_index.php';
}

echo "<div class='rowdown'>";
if(isset($_GET['id']))echo "<img src='/img/back.png' alt='' class='rpg' /> <a href='/farm/shop/'>Магазин семян</a><br/>";
echo "<img src='/img/back.png' alt='' class='rpg' /> <a href='/farm/garden/'>Моя ферма</a><br/>";
echo "<img src='/img/back.png' alt='' class='rpg' /> <a href='/farm/'>Назад</a>";
echo "</div>";

include_once '../sys/inc/tfoot.php';
?>