<?php
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();

$set['title']='Веселая ферма :: Игра';
include_once '../sys/inc/thead.php';
title();
err();
aut();

$dog = mysql_result(mysql_query("select count(*) from `farm_dog` WHERE  `id_user` = '$user[id]'  LIMIT 1"),0);
if ($dog==0)
{
mysql_query("INSERT INTO `farm_dog` (`id_user`,`time`) VALUES  ($user[id],NULL) ");
}
$post = mysql_result(mysql_query("select count(*) from `farm_gr` WHERE  `id_user` = '$user[id]'  LIMIT 1"),0);
if ($post<5)
{
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
mysql_query("INSERT INTO `farm_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user['id']."') ");
}

include_once 'inc/str.php';
farm_event();

echo "<div class='rowdown'><center><img src='img/logo.png' alt='' /></center></div>";

echo "<div class='mdlc'><span>Меню Игры</span><br /></div><div class='menu'>";

echo "<img src='/farm/img/garden.png' alt='' class='rpg' /> <a href='/farm/garden/'>Моя Ферма</a> (выйти к грядкам)<br/>";
echo "<img src='/farm/img/serdechko.png' alt='' class='rpg' /> <a href='/farm/dining'>Столовая</a> (пополнить здоровье)<br/>";
echo "<img src='/farm/img/money.png' alt='' class='rpg' /> <a href='/farm/exchanger'>Обменник</a> (обменник игровой валюты)<br/>";
echo "<img src='/farm/img/pet.gif' alt='' class='rpg' /> <a href='dog.php'>Моя собака</a> (купить собаку)<br/>";
echo "<img src='/farm/img/warehouse.png' alt='' class='rpg' /> <a href='/farm/sklad'>Мой склад</a> (склад с семенами)<br/>";
echo "<img src='/farm/img/warehouse.png' alt='' class='rpg' /> <a href='/farm/ambar'>Мой амбар</a> (склад с продукцией)<br/>";
echo "<img src='/farm/img/shop.png' alt='' class='rpg' /> <a href='/farm/shop/'>Магазин семян</a> (52 вида)<br/>";
echo "<img src='/farm/img/village.png' alt='' class='rpg' /> <a href='shop_udobr.php'>Магазин удобрений</a> (5 видов)<br/>";
echo "<img src='/farm/img/irrigation.png' alt='' class='rpg' /> <a href='/farm/shop_combine.php'>Магазин техники</a> (2 вида)<br/>";
echo "<img src='/farm/img/harvest.png' alt='' class='rpg' /> <a href='/farm/fermers/'>Все фермеры</a> (список фермеров)<br/>";
echo '</div>';

include_once '../sys/inc/tfoot.php';
?>