<?php
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();
$set['title']='Весёлая ферма :: Мои грядки';
include_once '../sys/inc/thead.php';
title();
err();
aut();

include 'inc/str.php';
farm_event();


if(isset($_GET['add_ok']))add_farm_event('Грядка успешно куплена');
if(isset($_GET['udobr_ok']))add_farm_event('Растение успешно удобрено');

if(isset($_GET['sob_ok']))
{
$semen1 = mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE `id` = '".intval($_SESSION['pid'])."' "));
add_farm_event('Вы успешно собрали '.$semen1['name'].'. Опыт +'.intval($_SESSION['opyt']).', здоровье -2.');
unset($_SESSION['pid']);
}

if(isset($_GET['watok']))
{
add_farm_event('Вы успешно полили грядку. Время до сбора урожая сократилось на [b]полчаса[/b].Опыт +1, здоровье -1.');
}

if(isset($_GET['saditok']))
{
$semen1 = mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE `id` = '".intval($_SESSION['pid'])."' "));
add_farm_event('Вы успешно посадили '.$semen1['name'].'. Опыт +1, здоровье -1.');
}

if (isset($_GET['add_no']))
{
add_farm_event('Ваш уровень слишком мал, либо у Вас не хватает денег на приобетение новой грядки');
}
if (isset($_GET['gr_add']) && $fuser['gold']>=5000)
{
$k_gr=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '$user[id]'"),0);
if ($k_gr==5)
{
$cost=500;
$lvl=0;
}
if ($k_gr==6)
{
$cost=1000;
$lvl=5;
}
if ($k_gr==7)
{
$cost=1500;
$lvl=10;
}
if ($k_gr==8)
{
$cost=2000;
$lvl=15;
}
if ($k_gr==9)
{
$cost=2500;
$lvl=20;
}
if ($k_gr==10)
{
$cost=3000;
$lvl=25;
}
if ($k_gr==11)
{
$cost=3500;
$lvl=30;
}
if ($k_gr==12)
{
$cost=4000;
$lvl=35;
}
if ($k_gr==13)
{
$cost=4500;
$lvl=40;
}
if ($k_gr==14)
{
$cost=5000;
$lvl=45;
}
if ($k_gr==15)
{
$cost=5500;
$lvl=50;
}

if(($fuser['gold']>=$cost) AND ($level>=$lvl)){
mysql_query("UPDATE `farm_user` SET `farm_gold` = ".($fuser['gold']-$cost)." WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("INSERT INTO `farm_gr` (`semen`, `id_user`) VALUES  ( '0', '".$user['id']."') ");
header('Location: /farm/garden/?add_ok');
}else{header('Location: /farm/garden/?add_no');}
}


if(isset($_GET['add'])){
$k_gr=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '$user[id]'"),0);
if ($k_gr==5)
{
$cost=500;
$lvl=0;
}
if ($k_gr==6)
{
$cost=1000;
$lvl=5;
}
if ($k_gr==7)
{
$cost=1500;
$lvl=10;
}
if ($k_gr==8)
{
$cost=2000;
$lvl=15;
}
if ($k_gr==9)
{
$cost=2500;
$lvl=20;
}
if ($k_gr==10)
{
$cost=3000;
$lvl=25;
}
if ($k_gr==11)
{
$cost=3500;
$lvl=30;
}
if ($k_gr==12)
{
$cost=4000;
$lvl=35;
}
if ($k_gr==13)
{
$cost=4500;
$lvl=40;
}
if ($k_gr==14)
{
$cost=5000;
$lvl=45;
}
if ($k_gr==15)
{
$cost=5500;
$lvl=50;
}




if ($level>=$lvl)
{
echo "<div class='rowup'><img src='/farm/img/garden.png' alt='' /> <a href='/farm/garden/'>Ваш огород</a> / <b>Добавляем грядку</b></div>";
echo "<div class='rowdown'>Стоимость одной грядки составляет: ".$cost." <br />";
echo "Требуемый уровень: ".$lvl."</div>";
echo "<form method='post' action='/farm/garden/?gr_add'>\n";
echo "<input type='submit' name='save' value='Приобрести' />\n";
echo "</form>\n";
}
else
{
echo "<div class='rowup'><img src='/farm/img/garden.png' alt='' /> <a href='/farm/garden/'>Ваш огород</a> / <b>Добавляем грядку</b></div>";
echo "<b>Вы не можете добавить грядку.</b><br />";
echo "У Bас не хватает <b>знаний</b>. Чтобы добавить еще одну грядку, Bам нужно больше <b>опыта</b>.<br />";
echo "Нет денег? <b>Заработайте</b> - общайтесь на форуме, пишите заметки и комментируйте чужие в дневниках, пишите статьи в газете, общайтесь и отгадывайте вопросы в чате. Способов <b>десятки!</b><br />";
}


}else{





$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '".$user['id']."'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];

farm_event();

echo "<div class='mdlc'><span>Список Ваших грядок [".$k_post."]</span><br /></div>";
echo "<div class='menu'>";

$res = mysql_query("select * from `farm_gr` WHERE `id_user` = '".$user['id']."'  LIMIT $start, $set[p_str];"); 

while ($post = mysql_fetch_array($res)){
if ($num==1)
{
echo "<div class='rowdown'>";
$num=0;
}
else
{
echo "<div class='rowup'>";
$num=1;
}


$semen=mysql_fetch_array(mysql_query("select * from `farm_plant` WHERE  `id` = '".$post['semen']."'  LIMIT 1")); 
if($post['semen']==0){$name_gr='Пустая грядка';}else{$name_gr=$semen['name'];}

$vremja=$post['time']-time();

$timediff=$vremja;
$oneMinute=60; 
$oneHour=60*60; 
$oneDay=60*60*24; 
$dayfield=floor($timediff/$oneDay); 
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour); 
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute); 
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute)); 
if($dayfield>0)$day=$dayfield.'д. ';

if(time()<$post['time'])$time_1="(".$day.$hourfield."ч. ".$minutefield."м.)";
else$time_1=" (<span class='off'>Пора собирать</span>)";

if($post['semen']!=0 && time()>$post['time'] && $post['kol']==0)
{
$pt=rand($semen['rand1'],$semen['rand2']);
mysql_query("UPDATE `farm_gr` SET `kol` = '".$pt."' WHERE `id` = '".$int."' LIMIT 1");
}

if ($post['semen']==0)
{
$plcnt = mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_semen` WHERE `id_user` = '".$user['id']."'"),0);
if ($plcnt==0)
{
$act = "Нет семян на складе. <a href='/farm/shop.php'>Купить</a>.";
}
if ($plcnt!=0)
{
$plant = mysql_fetch_array(mysql_query("SELECT * FROM `farm_semen` WHERE `id_user` = '".$user['id']."' ORDER BY id DESC LIMIT 1"));
$plnew = mysql_fetch_array(mysql_query("SELECT * FROM `farm_plant` WHERE `id` = '".$plant['semen']."' LIMIT 1"));
$act = "<img src='/farm/img/plant.png' alt='' class='rpg' /> Посадить <a href='/farm/gr.php?id=".$post['id']."&plantid=".$plant['id']."&posadka'>".$plnew['name']."</a> или <a href='/farm/gr.php?id=".$post['id']."'>выбрать другое растение</a>";
}
}

if ($post['semen']!=0)
{
if ($post['time_water']<time())
{
$act = "<img src='/farm/img/water.png' alt='' class='rpg' /> <a href='/farm/gr.php?id=$post[id]&water'>Полить</a>";
}

if ($post['time']<time())
{
$act = "<img src='/farm/img/harvest.png' alt='' class='rpg' /> <a href='/farm/gr/".$post['id']."'>Собрать</a>";
}
}


if ($post['semen']!=0 &&
$post['time']>time() && $post['time_water']>time())
{
$wost = $post['time_water']-time();
$timediff=$wost;
$oneMinute=60; 
$oneHour=60*60; 
$oneDay=60*60*24; 
$dayfield=floor($timediff/$oneDay); 
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour); 
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute); 
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute)); 
if($dayfield>0)$day=$dayfield.'д. ';
$time_wost=$day.$hourfield."ч. ".$minutefield."м.";
$act = "<img src='/farm/img/time.png' alt='' class='rpg' /> До полива ".$time_wost."";
}

if ($post['semen']!=0 && $post['udobr']==0 && $post['time_water']>time())
{
$act = "<img src='/farm/img/fertilize.png' alt='' class='rpg' /> <a href='/farm/gr/".$post['id']."'>Удобрить</a>";
}

if ($post['semen']!=0 && $post['udobr']==1 && $post['time_water']>time() && $post['time']>time() && $post['time']<$post['time_water'])
{
$act = "<img src='/farm/img/time.png' alt='' class='rpg' /> До сбора осталось: ".$time_1."";
}

echo "<table class='post'><tr><td rowspan='2' style='width:30px'>";
echo "<img src='/farm/plants/".$post['semen'].".png' height='30' width='30' alt='".$name_gr."' /></td><td> <a href='/farm/gr/".$post['id']."'>".$name_gr."</a>";
if($post['semen']!=0)
echo " ".$time_1."";
echo "</td>";
echo "</tr>";
echo "<tr><td>";
echo "".$act."";
echo "</td></tr>";
echo "</table>";
echo "</div>";
}
echo "</div>";


if ($k_page>1)str('?',$k_page,$page);
}

$irnum=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `time`>'".time()."' AND `time_water`<'".time()."'"), 0);
if ($irnum!=0 && $fuser['k_poliv']!=0)
{
if ($fuser['k_poliv']==1)
{
$irtime=10*$irnum;
$irexp=50*$irnum;
}
if ($fuser['k_poliv']==2)
{
$irtime=5*$irnum;
$irexp=100*$irnum;
}
if ($fuser['k_poliv']==3)
{
$irtime=3*$irnum;
$irexp=150*$irnum;
}
echo "<div class='rowdown'>";
echo "<img src='/farm/img/irrigation_small.png' alt='' class='rpg' /> <a href='/farm/shop_combine.php?irrigation'>Ороситель</a> (".$fuser['k_poliv']."/3 yp., ".$irtime." сек., +<img src='/farm/img/exp.png' alt='' />".$irexp.")<br />";
echo "<img src='/farm/img/water.png' alt='' class='rpg' /> <a href='/farm/combine/irrigation.php?start'>Полить грядки</a>";
echo "</div>";
}

$plcont = mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_semen` WHERE `id_user` = '".$user['id']."'"),0);
if ($plcont!=0)
{
$plseed = mysql_fetch_array(mysql_query("SELECT * FROM `farm_semen` WHERE `id_user` = '".$user['id']."' ORDER BY id DESC LIMIT 1"));
$pln = mysql_fetch_array(mysql_query("SELECT * FROM `farm_plant` WHERE `id` = '".$plant['semen']."' LIMIT 1"));
$act = "<img src='/farm/img/plant.png' alt='' class='rpg' /> Посадить <a href='/farm/gr.php?id=".$post['id']."&plantid=".$plant['id']."&posadka'>".$plnew['name']."</a> или <a href='/farm/gr.php?id=".$post['id']."'>выбрать другое растение</a>";
}
$snum=mysql_result(mysql_query("SELECT COUNT(*) FROM `farm_gr` WHERE `id_user` = '".$user['id']."' AND `semen` = '0'"), 0);
if ($snum!=0 && $fuser['k_posadka']!=0)
{
if ($fuser['k_posadka']==1)
{
$stime=10*$snum;
$sexp=50*$snum;
}
if ($fuser['k_posadka']==2)
{
$stime=5*$snum;
$sexp=100*$snum;
}
if ($fuser['k_posadka']==3)
{
$stime=3*$snum;
$sexp=150*$snum;
}
echo "<div class='rowdown'>";
if ($plcont!=0)
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' />  <a href='/farm/shop_combine.php?seeder'>Сеялка</a> (".$fuser['k_posadka']."/3 yp., ".$stime." сек., +<img src='/farm/img/exp.png' alt='' />".$sexp.")<br />";
echo "<img src='/farm/img/plant.png' alt='' class='rpg' /> <a href='/farm/combine/seeder.php?id=".$plseed['id']."&start'>Посеять ".$pln['name']."</a> <img src='/farm/img/plant.png' alt='' class='rpg' /> <a href='/farm/combine/seeder.php?select'>Другое</a>";
}
else
{
echo "<img src='/farm/img/seeder_small.png' alt='' class='rpg' /> <a href='/farm/combine/seeder.php?select'>Посадить сеялкой :: нет семян</a> (".$fuser['k_posadka']."/3 ур.)";
}
echo "</div>";
}

echo "<div class='rowup'>";
echo "<img src='/farm/img/shop.png' alt='' class='rpg' /> Магазин <a href='/farm/shop/'>семян</a> | <a href='/farm/shop_udobr.php'>удобрений</a> | <a href='/farm/shop_combine.php'>техники</a><br />";
echo "<img src='/farm/img/serdechko.png' alt='' class='rpg' /> <a href='/farm/dining'>Столовая</a><br />";
echo "<img src='/farm/img/warehouse.png' alt='' class='rpg' /> <a href='/farm/ambar'>Амбар</a> | <a href='/farm/sklad'>Склад</a><br/>";
echo "<img src='/farm/img/pet.gif' alt='' class='rpg' /> <a href='/farm/dog.php'>Моя собака</a><br/>";
echo "<img src='/farm/img/exp.png' alt='' class='rpg' /> <a href='/farm/abilities/'>Умения и Фишки</a><br/>";
echo "<img src='/farm/img/village.png' alt='' class='rpg' /> <a href='/farm/stat.php'>Статистика</a><br/>";
echo "<img src='/farm/img/harvest.png' alt='' class='rpg' /> <a href='/farm/fermers/'>Все фермеры</a><br/>";

if (!isset($_GET['add']))
{
echo "<img src='/img/add.png' alt='Купить грядку' class='rpg' /> <a href='/farm/garden/?add'>Добавить грядку</a> <a href='/farm/help.php'>[?]</a><br/>";
}

echo "<img src='/farm/img/garden.png' alt='Назад' class='rpg' /> <a href='/farm/garden/'>Назад</a><br/>";
echo "<img src='/img/back.png' alt='Назад' class='rpg' /> <a href='/farm/'>Нa главную</a>";
echo "</div>";

include_once '../sys/inc/tfoot.php';

?>