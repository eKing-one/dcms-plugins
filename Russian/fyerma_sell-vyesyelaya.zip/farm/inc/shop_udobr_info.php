<?php

$int=intval(htmlspecialchars(mysql_real_escape_string($_GET['id'])));
$query = mysql_query("select * from `farm_udobr_name` WHERE  `id` = '$int'  LIMIT 1");
$chk=mysql_num_rows($query);
if ($chk==0)
{
header("Location: /farm/shop_udobr.php");
exit();
}
$post=mysql_fetch_array($query);

$timediff=$post['time'];

$oneMinute=60; 
$oneHour=60*60; 
$oneDay=60*60*24; 
$dayfield=floor($timediff/$oneDay); 
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour); 
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute); 
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute)); 
if($dayfield>0)$day=$dayfield.'д. ';
if($minutefield>0)$minutefield=$minutefield."м.";else$minutefield='';
$time_1=$day.$hourfield."ч. ".$minutefield;

echo "<div class='rowdown'><img src='/farm/udobr/".$post['id'].".png' alt=''><br />&raquo; <b>".$post['name']."</b>";
echo "<br />&raquo; Цена: <b> ".$post['cena']."</b>";
echo "<br />&raquo; Сокращает на <b> ".$time_1."</b> рост растения";

echo "</div><form method='post' action='?id=".$int."&amp;$passgen'>\n";
echo "&raquo; Количество:<br />\n";

echo "<input type='text' name='kupit' size='4'/><input type='submit' name='save' value='Купить' />";
echo "</form>\n";
$kup=$post['cena']*$_POST['kupit'];
if(isset($_POST['kupit']) && $fuser['gold']>=$kup && $_POST['kupit']>0)
{
mysql_query("INSERT INTO `farm_udobr` (`kol` , `udobr`, `id_user`) VALUES  ('".intval($_POST['kupit'])."', '".$int."', '".$user['id']."') ");
mysql_query("UPDATE `farm_user` SET `gold` = `gold`- $kup WHERE `uid` = '".$user['id']."' LIMIT 1");
$_SESSION['udid']=$post['id'];
header('Location: shop_udobr.php?buy_ok');
}
if(isset($_POST['kupit']) && strlen2($_POST['kupit'])==0 || isset($_POST['kupit']) && $_POST['kupit']<1)echo "<div class='err'>Поле не заполнено!</div>";

if(isset($_POST['kupit']) && $fuser['gold']<$kup)
{
$_SESSION['udid']=$post['id'];
header('Location: shop.php?buy_no');
}
?>