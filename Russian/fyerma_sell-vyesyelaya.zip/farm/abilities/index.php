<?
include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/user.php';
only_reg();
$set['title']='Весёлая ферма :: Умения и фишки';
include_once '../../sys/inc/thead.php';
title();
aut();

include_once '../inc/str.php';
farm_event();
echo "<div class='mdlc'><span>Умения</span><br /></div><div class='menu'>";
echo "<img src='/farm/img/plus.gif' alt='' class='rpg' /> <a href='selection.php'>Селекция</a><br />";
echo "<img src='/farm/img/shield.gif' alt='' class='rpg' /> <a href='razvedka.php'>Разведка</a>";
echo "</div>";
echo "<div class='mdlc'><span>Оборудование</span><br /></div><div class='menu'>";
echo "<img src='/farm/img/electro.png' alt='' class='rpg' /> <a href='zabor.php'>Электрозабор</a> (аренда)<br />";
echo "<img src='/farm/img/tep.gif' alt='' class='rpg' /> <a href='teplica.php'>Теплица</a>";
echo "</div>";

echo "<div class='rowdown'>";
echo "<img src='/farm/img/garden.png' alt='' class='rpg' /> <a href='/farm/garden/'>Мои грядки</a>";
echo "</div>";
include_once '../../sys/inc/tfoot.php';
?>