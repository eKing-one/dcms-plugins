<?
include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/user.php';
only_reg();
$set['title']='Весёлая ферма :: Умение :: Разведка';
include_once '../../sys/inc/thead.php';
title();
aut();

$fuser=mysql_fetch_array(mysql_query("SELECT * FROM `farm_user` WHERE `uid` = '".$user['id']."' LIMIT 1"));

if (isset($_GET['learn']) && $fuser['razvedka']==0)
{
if ($fuser['gems']<35)
{
add_farm_event('Для изучения данного умения у Вас не хватает алмазов');
}
else
{
mysql_query("UPDATE `farm_user` SET `razvedka` = '1' WHERE `uid` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `farm_user` SET `gems` = `gems`-'35' WHERE `uid` = '".$user['id']."' LIMIT 1");
add_farm_event('Вы успешно изучили умение [b]Развека[/b] за 35 алмазов');
}
}

include_once '../inc/str.php';
farm_event();
echo "<div class='rowup'>Умение :: Разведка</div>";
echo "<div class='rowdown'>";
echo "<table class='post'><tr><td><img src='/farm/img/shield.gif' alt='' /></td><td>Умение <b>Разведка</b> даёт возможность видеть собаку за забором обворовываемого фермера. Также дает возможность определять, проведён ли ток в электрическом заборе.</td></tr></table>";
if ($fuser['razvedka']==0)
{
echo "<img src='/img/add.png' alt='' class='rpg' /> <span class='underline'><a href='?learn'>Выучить умение за <img src='/farm/img/gems.png' alt='' class='rpg' />35</a></span>";
}
else
{
echo "<img src='/img/accept.png' alt='' class='rpg' /> Умение уже изучено";
}
echo "</div>";

echo "<div class='rowdown'>";
echo "<img src='/img/back.png' alt='' class='rpg' /> <a href='/farm/abilities/'>К списку умений</a><br />";
echo "<img src='/farm/img/garden.png' alt='' class='rpg' /> <a href='/farm/garden/'>Мои грядки</a>";
echo "</div>";
include_once '../../sys/inc/tfoot.php';
?>