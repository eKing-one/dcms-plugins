<?php
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
only_reg();
$set['title']='Весёлая ферма :: Помощь';
include_once '../sys/inc/thead.php';
title();
err();
aut();

include 'inc/str.php';
farm_event();

if (isset($_GET['weather']))
{
echo "<div class='rowup'>";

if ($conf['weather']==1)
{
$uro="+3";
$name="умеренная";
}
if ($conf['weather']==2)
{
$uro="+2";
$name="облачная, без прояснений";
}
if ($conf['weather']==3)
{
$uro="-1";
$name="дождливая";
$uron="-1";
}
if ($conf['weather']==4)
{
$uro="-3";
$name="гроза";
$uron="-3";
}
if ($conf['weather']==5)
{
$uro="+1";
$name="солнечная";
}

if ($fuser['teplica']==1)
{
if ($uro<0)
{
$uro=0;
$mess=true;
}
}

echo "<img src='/farm/img/garden.png' alt='' class='rpg' /> Текущая погода: <img src='/farm/weather/".$conf['weather'].".png' alt='' />".$name."<br />";
echo "<img src='/img/add.png' alt='' class='rpg' /> Влияние: ".$uro." ";
if (isset($mess))
{
echo "(".$uron.") ";
}
echo "к урожаю";
if (isset($mess))
{
echo "<br /><img src='/img/accept.png' alt='' class='rpg' /> У Вас изучено умение <b>Теплица</b>. Отрицательный эффект погоды не влияет на Ваш урожай";
}
echo "</div>";
}

if (!isset($_GET['weather']))
{
echo "<div class='rowup'><b>Когда я могу добавить еще одну грядку?</b></div>";
echo "<div class='rowdown'>В самом начале вам дается пять бесплатных грядок. Последующие на 500 золотых дороже предыдущей. После того,как у вас стало 6 грядок, остальные требуют определенного уровня.<br />";
echo "Грядки можно купить после набора следующих уровней: <b>5, 10, 15, 20, 25, 30, 35, 40, 45, 50</b>.<br />";
echo "В итоге у вас оказывается максимум <b>шестнадцать</b> грядок.<br />";
echo "Сейчас Ваш уровень: ".$level.", золота ".$fuser['gold']."";
}

echo "</div><div class='rowup'>";
echo "<img src='/img/back.png' alt='Назад' class='rpg' /> <a href='/farm/garden/'>Мои грядки</a><br/>";
echo "</div>";

include_once '../sys/inc/tfoot.php';

?>