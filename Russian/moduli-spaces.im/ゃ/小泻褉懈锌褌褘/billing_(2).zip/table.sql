alter table `user` add `billing` int(11) NOT NULL;

CREATE TABLE IF NOT EXISTS `billing` (
  `wmr` varchar(15) NOT NULL,
  `secretKey` varchar(150) NOT NULL,
  `nick` int(11) NOT NULL,
  `balls` int(11) NOT NULL,
  `money` int(11) NOT NULL,
  `icon` int(11) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

INSERT INTO `billing` (`wmr`, `secretKey`, `nick`, `balls`, `money`, `icon`, `stat`) VALUES ('0', '0', '1', '1', '1', '1', '0');

CREATE TABLE IF NOT EXISTS `billing_operations` (
  `id_user` int(11) NOT NULL,
  `wmr` int(11) NOT NULL,
  `op` varchar(12) NOT NULL,
  `time` int(11) NOT NULL,
  `id_user2` int(11) NOT NULL,
  `comm` varchar(1000) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;