ALTER TABLE `user` ADD `strana_icon` INT( 11 ) NOT NULL ,
ADD `strana_text` VARCHAR( 150 ) NOT NULL