ALTER TABLE `user` ADD `id_sp` int(11) DEFAULT '0';
ALTER TABLE `user` ADD `sem_poloj` enum('0','1','2','3','4','5','6','7','8','9','10','11','12','13','14') NOT NULL DEFAULT '0';