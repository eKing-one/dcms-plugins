<?
echo "<style type='text/css'>
.block_hr {border-bottom:1px dotted #abbefb}
div.row3{padding:1px;background-color:#e1e1e1}
div.row4{padding:1px;background-color:#ffffff}
div.backlink{background-color:#EFF3F6;padding:2px}
div.blueline{padding:1px;background-color:#e7f1fe;border-top:1px solid #99ccff;border-bottom:1px solid #AFCDDC}
div.even{padding:1px;background-color:#fff;border-top:1px dotted #CCC}
div.block{margin:2px;padding:1px;border-top:1px dotted gray;border-bottom:1px dotted gray}
div.busi{padding:2px;background-color:#fff9d7;border-top:1px solid #e2c822;border-bottom:1px solid #e2c822}
div.header_path{border-left:1px solid #abbefb;border-right:1px solid #abbefb;border-bottom:1px solid #abbefb;border-left: 1px solid #999999;border-right: 1px solid #999999;background:#e8e8e8;margin:0px;padding:3px}
div.odd{padding:1px;background-color:#edeff4;border-top:1px dotted #CCC}
div.title1{padding:3px;background-color:#d7ddf8;border-bottom:1px dotted #AFCDDC}
img.icon {vertical-align: middle}
.clear{ clear:both}</style>\n";
?>