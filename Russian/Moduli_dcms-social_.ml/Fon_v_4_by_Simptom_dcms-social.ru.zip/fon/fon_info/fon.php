<?
echo "<style type='text/css'>
.fon_info1 {
background-image: url('fon/img/1.jpg');
background-repeat: repeat-auto;
}
.fon_info2 {
background-image: url('fon/img/2.jpg');
background-repeat: repeat-auto;
}
.fon_info3 {
background-image: url('fon/img/3.jpg');
background-repeat: repeat-auto;
}
.fon_info4 {
background-image: url('fon/img/4.jpg');
background-repeat: repeat-auto;
}
.fon_info5 {
background-image: url('fon/img/5.jpg');
background-repeat: repeat-auto;
}
.fon_info6 {
background-image: url('fon/img/6.jpg');
background-repeat: repeat-auto;
}
.fon_info7 {
background-image: url('fon/img/7.jpg');
background-repeat: repeat-auto;
}
.fon_info8 {
background-image: url('fon/img/8.jpg');
background-repeat: repeat-auto;
}
.fon_info9 {
background-image: url('fon/img/9.jpg');
background-repeat: repeat-auto;
}
</style>";
?>