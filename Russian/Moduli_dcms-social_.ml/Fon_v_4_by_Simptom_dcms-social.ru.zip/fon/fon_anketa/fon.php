<?
echo "<style type='text/css'>
.fon_anketa1 {
background-image: url('fon/img/1.jpg');
background-repeat: repeat-auto;
}
.fon_anketa2 {
background-image: url('fon/img/2.jpg');
background-repeat: repeat-auto;
}
.fon_anketa3 {
background-image: url('fon/img/3.jpg');
background-repeat: repeat-auto;
}
.fon_anketa4 {
background-image: url('fon/img/4.jpg');
background-repeat: repeat-auto;
}
.fon_anketa5 {
background-image: url('fon/img/5.jpg');
background-repeat: repeat-auto;
}
.fon_anketa6 {
background-image: url('fon/img/6.jpg');
background-repeat: repeat-auto;
}
.fon_anketa7 {
background-image: url('fon/img/7.jpg');
background-repeat: repeat-auto;
}
.fon_anketa8 {
background-image: url('fon/img/8.jpg');
background-repeat: repeat-auto;
}
.fon_anketa9 {
background-image: url('fon/img/9.jpg');
background-repeat: repeat-auto;
}
</style>";
?>