<?
echo "<style type='text/css'>
.fon_info1 {
background-image: url('fon/img_info/$ank[id].png');
background-repeat: repeat-auto;
}
.fon_info2 {
background-image: url('fon/img_info/$ank[id].jpg');
background-repeat: repeat-auto;
}
.fon_info3 {
background-image: url('fon/img_info/$ank[id].gif');
background-repeat: repeat-auto;
}
.fon_anketa1 {
background-image: url('fon/img_anketa/$ank[id].png');
background-repeat: repeat-auto;
}
.fon_anketa2 {
background-image: url('fon/img_anketa/$ank[id].jpg');
background-repeat: repeat-auto;
}
.fon_anketa3 {
background-image: url('fon/img_anketa/$ank[id].gif');
background-repeat: repeat-auto;
}
</style>";
?>