<?
$search_name = 'Поиск по сайту';
$search_opis = 'Поиск по сайту:';
$placeholder = 'Что ищем?';
$submit = 'Искать';

// Цвет выделения найденного
$color = 'green';

########### Иконки поиска ##############
$icon_people = '/style/icons/druzya.png';
$icon_obmen = '/style/icons/obmen.png';
$icon_notes = '/style/icons/zametki.gif';
$icon_forum = '/style/icons/forum.png';
?>