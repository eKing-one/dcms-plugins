Модуль поиска по сайту:
- Поиск обитателей (IP, ID, Ник, Email, ICQ, Город)
- Поиск дневников
- Поиск видео
- Поиск музыки
- Поиск по форуму
- Поиск Файлов (общее)

Установка:
Распаковать в корень

Форма для вывода поиска:

?>
<form action="/plugins/search/?search" method="post" class="mess">
<input type="text" name="search" value="" placeholder="Поиск по сайту.."/> 
<input type="submit" value="Искать"/><br />
Люди, Форум, Файлы, Дневники..
</form>
<?