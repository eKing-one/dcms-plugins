﻿<div class="foot">© <a href="http://site.ru">Site.Ru</a></div>
</body>
</html>