﻿<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Cache-Control" content="no-cache" />
<meta name="description" content="Погода." />
<meta name="keywords" content="погода на месяц, погода в москве, погода в одессе, погода киев, погода в минске" />
<link rel="shortcut icon" href="/weather/style/images/favicon.ico" />
<link rel="stylesheet" href="/weather/style/style.css" type="text/css" />
<title>Погода на Vaydu.Ru</title>
</head>
<body>
<div class="head"><a href="/"><span><i><?=$_SERVER['HTTP_HOST'];?></i></span></a></div>