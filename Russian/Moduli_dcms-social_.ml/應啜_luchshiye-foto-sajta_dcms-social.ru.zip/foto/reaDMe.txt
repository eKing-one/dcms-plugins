Распаковать с корене и в удобном для вас месте прописать: 

echo "<div class='foot'><img src='/style/icons/str.gif'> <a href='/foto/rating.php'>Лучшие фото сайта!</a></div>";

Если возникли проблемы с установкой, пишите мне в аську: 656770803
(c) Optimuses 
