CREATE TABLE `ncolor` (
`cena1` varchar(15) NOT NULL,
`cena2` varchar(15) NOT NULL 
);
INSERT INTO `ncolor` (`cena1` ,`cena2` )VALUES ('200', '100');
ALTER TABLE `user` ADD `ncolor2` varchar(10) NOT NULL;
ALTER TABLE `user` ADD `ncolor` varchar(10) NOT NULL;


