﻿Добавь в index.php в корне в то место в котором будет выводить аватарки 

include ('services/photo_lineup/photo_lineup.statusinc.php');

Установка
Распаковать в корень и прописать код в index.php