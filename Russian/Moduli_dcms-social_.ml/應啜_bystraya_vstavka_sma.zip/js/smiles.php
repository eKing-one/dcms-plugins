<?
?>
<a href="javascript:%20x()" onclick="DoSmilie(' :-) ');"><img src="/style/smiles/smile.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' :-( ');"><img src="/style/smiles/sad.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' :-D ');"><img src="/style/smiles/biggrin.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' ;-) ');"><img src="/style/smiles/wink.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' :-P ');"><img src="/style/smiles/blum3.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' :cool: ');"><img src="/style/smiles/dirol.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' *YES* ');"><img src="/style/smiles/yes3.gif" alt="smile"></a><a href="javascript:%20x()" onclick="DoSmilie(' :happy: ');"><img src="/style/smiles/i-m_so_happy.gif" alt="smile"></a><a href='/smiles.php'>>></a>
</div>
<?
?>