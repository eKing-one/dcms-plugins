<?
?>
<div class="post">
<script src="/js/qbbcodes.js"></script>
<a href="javascript:tag(' [url=]', '[/url] ')"><img src="/images/l.png" alt="url" title="Ссылка"></a><a href="javascript:tag(' [b]', '[/b] ')"><img src="/images/b.png" alt="b" title="Жирный"></a><a href="javascript:tag(' [i]', '[/i] ')"><img src="/images/i.png" alt="i" title="Наклонный"></a><a href="javascript:tag(' [u]', '[/u] ')"><img src="/
images/u.png" alt="u" title="Подчёркнутый"></a><br>
<?
?>