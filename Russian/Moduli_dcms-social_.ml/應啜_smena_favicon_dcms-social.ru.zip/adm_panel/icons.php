<?
echo"<a href='http://Xak-Pro.Ru'>Лутший Хак.Форум</a>";
?>