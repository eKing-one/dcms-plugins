ALTER TABLE `user` ADD `on_i` INT( 11 ) NOT NULL
