<?
echo "<span style='float : right;'>\n";
echo "<a href='/'><img src='/style/img/strana/ru.png' alt='' /></a>";
echo "<a href='http://translate.google.ru/translate?hl=ru&amp;sl=auto&amp;tl=en&amp;u=http%3A%2F%2F$_SERVER[HTTP_HOST]%2F'><img src='/style/img/strana/usa.png' alt='' /></a>";
echo "<a href='http://translate.google.ru/translate?hl=ru&amp;sl=auto&amp;tl=de&amp;u=http%3A%2F%2F$_SERVER[HTTP_HOST]%2F'><img src='/style/img/strana/de.png' alt='' /></a>";
echo "<a href='http://translate.google.ru/translate?hl=ru&amp;sl=auto&amp;tl=uk&amp;u=http%3A%2F%2F$_SERVER[HTTP_HOST]%2F'><img src='/style/img/strana/ua.png' alt='' /></a>";
echo "</span>";
?>