<?php
if ($_FILES['file']['size'] > 0)echo '��!';
?>