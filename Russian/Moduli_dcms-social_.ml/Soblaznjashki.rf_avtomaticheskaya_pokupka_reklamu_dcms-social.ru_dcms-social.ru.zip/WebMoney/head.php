<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
	<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<link rel="stylesheet" href="style_rekl.css" type="text/css" />
	<title>Покупка рекламы Merchant</title>
</head>
<html>
<body>


