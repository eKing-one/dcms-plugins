<?php
#---------------#
#   by Skater   #
# Icq : 7267593 #
#---------------#
echo '<link rel="stylesheet" href="../theme/style.css" type="text/css">';
echo '<title>Design studio - �����</title>';
echo '<div><img src="../theme/img/logo.gif" alt=""/></div>';
	
echo '<div class="header">����� ���������</div>';
echo '<br>';


echo '<div class="maintxt"><div class="bmenu"><img src="../theme/img/str.gif"/> ��������</div>';
echo '<div class="menu">Icq : .....<br></div>';
echo '<div class="menu">email : .....<br></div>';

echo '<div class="bmenu"> <a href="/index.php">�� �������</a><br></div>';
echo '<div class="footer">&copy; Design studio</div>';
	
	echo '<div><center><a href="http://wap-scripts.ru">Power by Skater</a><br></center></div>';
echo '<div class="end"><b></b><br/></div>';


?>