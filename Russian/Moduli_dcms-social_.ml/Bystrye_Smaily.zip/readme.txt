////Быстрые смайлы///
/// DCMS-SOCIAL.RU //
///Автор: ХАСАНОВ ///
///ICQ: 614643513. //

Версия написан на
DCMS-Social v.1.7.9 beta

Установка:

Файл: smailes.php
Кидаем в
style/themes/default/smailes.php

Заминит файлы гостевой index.php
И почту mail.php и все радуемься


