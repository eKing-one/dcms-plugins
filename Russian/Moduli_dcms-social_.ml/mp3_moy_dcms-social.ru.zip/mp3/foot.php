<?php
/*
<div class="footer">&copy; Keemo.Ru 2o14</div>
</body>
</html>
*/
require_once('../sys/inc/tfoot.php');
?>