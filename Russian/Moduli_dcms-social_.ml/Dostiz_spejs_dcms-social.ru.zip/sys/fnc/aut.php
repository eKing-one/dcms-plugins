<?
function title()
{
	global $user;	
	
	if (isset($user))
	{
		global $set;		
		
		if ($set['web'] == false)
		{			
			?><table style="width:100%" cellspacing="0" cellpadding="0"><tr><?
		
			$k_new = mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
			 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
			 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);
			 
			$k_new_fav = mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
			 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
			 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0); // Почта			
			 
			 $lenta = mysql_result(mysql_query("SELECT COUNT(`read`) FROM `tape` WHERE `id_user` = '$user[id]' AND `read` = '0' "),0); // Лента			
			 
			 $discuss = mysql_result(mysql_query("SELECT COUNT(`count`) FROM `discussions` WHERE `id_user` = '$user[id]' AND `count` > '0' "),0); // Обсуждения			
			 
			 $k_frend = mysql_result(mysql_query("SELECT COUNT(id) FROM `frends_new` WHERE `to` = '$user[id]'"), 0); // Друзья			
			 
			 $k_notif = mysql_result(mysql_query("SELECT COUNT(`read`) FROM `notification` WHERE `id_user` = '$user[id]' AND `read` = '0'"), 0); // Уведомления			 
			 
			/*
			=================================
			Страничка
			=================================
			*/			
			
			?>
			<td class="auts">
			<a href="/info.php?id=<?=$user['id']?>"><center><img src="/style/icons/nav_stranica.gif" alt="DS" /></center></a>
			</td>
			<?
			
			/*
			=================================
			Почта
			=================================
			*/			
			
			?><td class="auts"><?
			if ($k_new != 0 && $k_new_fav == 0)
			{				
				?><a href="/new_mess.php"><center><img src="/style/icons/icon_pochta22.gif" alt="DS" /><font color="#ff0000">(<?=$k_new?>)</font></center></a><?
			}
			else
			{
				?><a href="/konts.php"><center><img src="/style/icons/nav_pochta.gif" alt="S" /></center></a><?
			}
			?></td><?
			
			/*
			=================================
			Лента
			=================================
			*/
			
			if ($lenta > 0)
			{
				$j2 = 'tape';
			}
			elseif ($discuss > 0)
			{
				$j2 = 'discussions';
			}
			elseif ($k_notif > 0)
			{
				$j2 = 'notification';
			}
			else
			{
				$j2 = 'tape';
			}
			
			?>
			<td class='auts'>
			<a href="/user/<?=$j2?>/index.php"><center><img src="/style/icons/nav_lenta.gif" alt="DS" />
			<?
			// Cкладываем сумму счетчиков
			$k_l = $lenta + $k_notif + $discuss;
			
			if($k_l > 0)
			{
				?>
				<font color="#ff0000">(<?=$k_l?>)</font>
				<?
			}
			?>
			</center></a>
			</td>
			<?
			/*
			=================================
			Друзья
			=================================
			*/			 
			
			if ($k_frend > 0)
			{
				?>
				<td class='auts'>
				<a href="/user/frends/new.php"><center><img src="/style/icons/icon_druzya.gif" alt="DS" /><font color='red'>(<?=$k_frend?>)</font></center></a>
				</td>
				<?
			}			
			
			/*
			=================================
			Обновить
			=================================
			*/
			
			?>
			<td class='auts'>
			<a href="<?=text($_SERVER['REQUEST_URI'])?>"><center><img src="/style/icons/nav_obnovit.gif" alt="DS" /></center></a>
			</td>		
			</tr></table>
			<?
		}
	}
}







function medal_ikey($user = 0)
{
	$ank = mysql_fetch_array(mysql_query("SELECT `ikey_reit` FROM `user` WHERE `id` = $user LIMIT 1"));
	
	$img = 0;

	if ($ank['ikey_reit'] >= 10 && $ank['ikey_reit'] <= 30)
		$img = 1;
		
	elseif ($ank['ikey_reit'] >= 31 && $ank['ikey_reit'] <= 50)
		$img = 2;

	elseif ($ank['ikey_reit'] >= 51 && $ank['ikey_reit'] <= 9999999)
		$img = 3;

	
	
	if ($img != 0)
	{
		return ' <img src="/reit/img/medal/' . $img . '.gif" alt="iKey" />';
	}
}
?>
