<?
?>
<html>
<style>
.oh {
overflow:hidden
 }
.rate_arrow { 
display:inline-block;text-decoration:none !important;position:relative;padding:3px 2px 3px 13px;height:13px;line-height:13px;font-size:12px;background:url('img/style/rate_arrow.png') -3px 0 no-repeat;
}

.rate_arrow_end {
position:absolute;top:0;bottom:0;width:3px;left:100%;background:url('img/style/rate_arrow.png') 0 0 no-repeat;
}
</style>
</html>
<?

?>