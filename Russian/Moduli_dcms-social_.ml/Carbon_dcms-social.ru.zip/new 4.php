<div id="header">
                <div id="banner">
          <div id="banner_inner">
<?
echo "<div class='rekl'>\n";
rekl(3);
echo "</div>\n";
?>          </div>
        </div>
              </div></td>
  </tr>
    <tr>
    <td><div id="top_menu">
        <div id="top_menu_inner">
          		<table cellpadding="0" cellspacing="0" class="moduletable">
		<tr>
			<td>
<ul id="mainlevel-nav">
<li><a href="/" class="mainlevel-nav"  title="Главная">Главная</a></li>
<li><a href="/forum/" class="mainlevel-nav"  title="Форум">Форум</a></li>
<li><a href="http://d-chat.ru" class="mainlevel-nav"  title="D-ChAT">D-ChAT</a></li>
<li><a href="/news/" class="mainlevel-nav"  title="Новости">Новости</a></li>
<li><a href="/loads/" class="mainlevel-nav"  title="Скрипты,загрузки,дизайны">Скрипты,загрузки,дизайны</a></li>
</ul>			</td>
		</tr>
		</table>
		</div>
      </div></td>
  </tr>
      <tr>
    <td><div id="top_menu_top_two">
        <div id="top_menu_top_two_inner">
          <div id="search_inner">
            <form action="index.php" method="post">
              <div align="center">
              </div>
            </form>
          </div>
        </div>
      </div></td>
  </tr>
      <tr>
    <td><div id="top_menu_top">
        <div id="top_menu_top_inner">
          		<table cellpadding="0" cellspacing="0" class="moduletable">
		<tr>
			<td>
			</td>
		</tr>
		</table>
        </div>
      </div></td>
  </tr>
    <tr>