</div>
                    </div>
                  </div></td>
                              </tr>
              <tr>
                <td colspan="3"></td>
              </tr>
                          </tbody></table>
            <div align="center">
              <div id="content_bottom_bar">
                <div id="content_bottom">
                  <div id="content_right_bottom"></div>
                </div>
              </div>
            </div></td>
</td><td width='20%' class='table_right'>
<?
include_once H.'style/themes/'.$set['set_them'].'/aut.php';
?></div>
            </div></td>
</tbody></table>
      <div align="center">
        <div id="copy">
          <div id="copy_inner" class="copy_inner">Design<a href="http://dleif.ru" target="_blank"> Dleif </a> for<!--Design <br /><a href='http://dleif.ru'> Dleif </a> for В бесплатной версии не убирать (если хотите чтобы я их писал!!!)--><strong><a href="http://dcms.su/" target="_blank"> DCMS</a></strong></div>
        </div>
      </div></td>
  </tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td width='100%' colspan='3'>

</td>
</tr>
</table>
<?

echo "</div>\n</body>\n</html>";
exit;
?>