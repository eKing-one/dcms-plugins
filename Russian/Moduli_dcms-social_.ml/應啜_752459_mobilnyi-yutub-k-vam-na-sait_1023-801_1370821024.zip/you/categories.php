<?php
include("page_head.php");
?>
    
<div class="header">Категории</div>

<div class="menu3">
<a href="autos.php">Автомобили & Техника</a><br/>
<a href="comedy.php">Комедии</a><br/>
<a href="education.php">Образование</a><br/>
<a href="entertainment.php">Вечеринки</a><br/>
<a href="film.php">Фильмы & Мультфильмы</a><br/>
<a href="gaming.php">Игры</a><br/>
<a href="howto.php">Обучение & Стиль</a><br/>
<a href="music.php">Музыка</a><br/>
<a href="news.php">Новости & Политика</a><br/>
<a href="people.php">Люди & Блоги</a><br/>
<a href="animals.php">Животные</a><br/>
<a href="tech.php">Технологии</a><br/>
<a href="sports.php">Спорт</a><br/>
<a href="travel.php">Путешествия & Соревнования</a><br/>
</div>

<?php
include("footer3.php");
?>