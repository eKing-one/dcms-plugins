<?
if (user_access('adm_set_sys')) {
?>
	<div class="main">
	<img src="/style/icons/str.gif" alt="*" /> <a href="settings_roller.php">Перекличка пользователей</a>
	</div>
<?
}
?>