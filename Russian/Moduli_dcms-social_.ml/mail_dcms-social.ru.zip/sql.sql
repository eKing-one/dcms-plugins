alter table `mail` add `ras` varchar(5) default null;
alter table `mail` add `file` varchar(128) default null;