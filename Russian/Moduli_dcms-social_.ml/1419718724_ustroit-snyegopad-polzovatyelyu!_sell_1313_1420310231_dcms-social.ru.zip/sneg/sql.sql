ALTER TABLE `user` ADD `sneg_s` INT( 11 ) NOT NULL;
ALTER TABLE `user` ADD `time_sneg` INT( 11 ) NOT NULL;