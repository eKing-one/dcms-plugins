﻿<?
if (user_access('dell_user_avatar')) echo "<a href='del_avatar.php'>Удаление аватара пользователя</a><br />";
?>