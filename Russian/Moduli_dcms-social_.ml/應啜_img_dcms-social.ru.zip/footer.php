<?php
/*
уход с сервера
*/
mysql_close($sql);
echo $hr."" . $counter . "</div></body></html>";
?>

