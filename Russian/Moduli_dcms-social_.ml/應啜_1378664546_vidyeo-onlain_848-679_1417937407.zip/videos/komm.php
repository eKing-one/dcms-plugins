<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
//////////////////////////////////////////////
if (isset($_GET['id']) && is_numeric($_GET['id']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `videos` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"),0)!=0)
{
$videos=mysql_fetch_array(mysql_query("SELECT * FROM `videos` WHERE `id`='".intval($_GET['id'])."'"));
$us=get_user($videos['id_user']);
$set['title']=''.$videos['name'].' - Комментарии';
include_once '../sys/inc/thead.php';
title();
$id=intval($_GET['id']);
///////////////////////////////////////////////
if (isset($_POST['msg']) && isset($user) ) 
{
$msg=esc(stripcslashes(htmlspecialchars($_POST['msg'])));
if (isset($_POST['translit']) && $_POST['translit']==1)$msg=translit($msg);
if (strlen2($msg)>1024){$err='Сообщение слишком длинное';}
elseif (strlen2($msg)<2){$err='Короткое сообщение';}
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `videos_komm` WHERE `id_videos` = '$id' AND `id_user` = '$user[id]' AND `msg` = '".mysql_real_escape_string($msg)."' LIMIT 1"),0)!=0){$err='Ваше сообщение повторяет предыдущее';}
else{
mysql_query("INSERT INTO `videos_komm` (`id_videos`, `id_user`, `time`, `msg`) values('$id', '$user[id]', '$time', '".my_esc($msg)."')");
mysql_query("UPDATE `user` SET `balls` = '".($user['balls']+1)."' WHERE `id` = '$user[id]' LIMIT 1");

if($user['id']!=$us['id'])
{
if($user['pol']==1)$pol='оставил'; else $pol='оставила';
mysql_query("INSERT INTO `jurnal` (`id_user`, `id_kont`, `msg`, `time`, `type`) values('0', '$us[id]', '[url=/info.php?id=$user[id]]$user[nick][/url] $pol комментарий к видео [url=/videos/video.php?id=".$id."]".$videos['name']."[/url]', '$time', 'blog')");}

msg('Комментарий успешно оставлен');
 {header("Location: komm.php?id=".$id."");exit;}

}
}
elseif (isset($_GET['del']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `videos_komm` WHERE `id` = '".intval($_GET['del'])."' AND `id_videos` = '$videos[id]'"),0))
{
if (isset($user) && ($user['level']>=3 || $user['id']=$videos['id_user']))
{
mysql_query("DELETE FROM `videos_komm` WHERE `id` = '".intval($_GET['del'])."' LIMIT 1");
msg('Комментарий успешно удален');
 {header("Location: komm.php?id=".$id."");exit;}

}
}
err();
aut(); 
////////////////////////////////////////////////////////
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `videos_komm` WHERE `id_videos` = '$id'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
$q=mysql_query("SELECT * FROM `videos_komm` WHERE `id_videos` = '".intval($_GET['id'])."' ORDER BY `id` DESC LIMIT $start, $set[p_str]");
echo'<table class="post">';
if ($k_post==0)
{
echo'<tr>';
echo'<td class="p_t">';
echo'Нет комментариев';
echo'</td>';
echo'</tr>';
}
while ($post = mysql_fetch_assoc($q))
{
$ank=get_user($post['id_user']);
//////////////////////////////////////////////////////////////

echo'<tr>';
if ($set['set_show_icon']==2){
echo'<td class="icon48" rowspan="2">';
avatar($ank['id']);
echo'</td>';
}
elseif ($set['set_show_icon']==1)
{
echo'<td class="icon14">';
avatar($ank['id']);
echo'</td>';
}
echo'<td class="p_t">';
echo'<a href="/info.php?id='.$ank['id'].'"><span style="color:'.$ank['ncolor'].'">'.$ank['nick'].'</span></a> ('.vremja($post['time']).')';
echo'</td>';
echo'</tr>';
echo'<tr>';
if ($set['set_show_icon']==1)echo'<td class="p_m" colspan="2">'; else echo'<td class="p_m">';
echo output_text($post['msg'])."<br />\n";
if (isset($user) && ($user['level']>=3 || $user['id'] == $videos['id_user']))
echo'<a href="?id='.$videos['id'].'&del='.$post['id'].'">Удалить</a><br />';
echo'</td>';
echo'</tr>';
}
echo'</table>';
////////////////////////////////////////////////////////
if ($k_page>1)str("komm.php?id=$videos[id]&",$k_page,$page); // Вывод страниц

if (!isset($_POST['msg']) && isset($user) ) 
{
echo'<form method="post" name="message" action="?id='.$videos['id'].'">';

if ($set['web'] && is_file(H.'style/themes/'.$set['set_them'].'/altername_post_form.php'))
include_once H.'style/themes/'.$set['set_them'].'/altername_post_form.php';
else
echo'Сообщение<br /><textarea name="msg"></textarea><br />';
if ($user['set_translit']==1)echo'<label><input type="checkbox" name="translit" value="1" /> Транслит</label><br />';
echo'<input value="Отправить" type="submit" />';
echo'</form>';

}
//////////////////////////////////////////////////////////
echo'<div class="foot">';
echo'<a href="video.php?id='.$id.'" title="К видео">К видео</a><br />';
echo'<a href="index.php" title="К категориям">К разделам</a><br />';

echo"</div>\n";
}
else
{
header("Location: index.php?".SID);
exit;
}
include_once '../sys/inc/tfoot.php';
?>

