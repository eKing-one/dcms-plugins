<?php
header('Location: search.php?do=users');
?>