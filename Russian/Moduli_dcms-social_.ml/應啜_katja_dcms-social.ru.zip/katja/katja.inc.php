<?php
echo "<div class='main2'><table><td><img src='/katja/img/ava_katja.png' alt='W'></td><td><img src='/katja/img/icon_katja.png' alt='W'> <b>Катюша</b> <img src='/style/medal/6.png' alt='W'><img src='/style/icons/online_web.gif' alt='W'><br/>Привет! Пообщаемся???<br/><a href='/katja/'><img src='/style/icons/msg.gif' alt='W'> Написать</a></td></table></div>";
?>